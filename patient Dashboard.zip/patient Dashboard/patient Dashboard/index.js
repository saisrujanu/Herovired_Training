const express = require('express');
// const myRouter = require('./myRouter');
const app = express();
var path = require('path')

const cookieParser = require("cookie-parser");
const sessions = require('express-session');
// var collection=require("./models/newfooditems_schema");
app.use(sessions({
    cookieName: "sessions",
    secret: "vishnu",
    saveUninitialized:true,
    resave: false

}));
// app.get('/mainpage',function(req,res){
//     session=req.session;
//     if(session.user){
//         console.log(session.user);
//         res.sendFile(__dirname +'/pages/index.html');
//     }
//     else{
//         res.redirect("/")
//     }
  
//   });


app.use(express.json());
app.use(express.urlencoded({extended:false}))

app.use(express.static(path.join(__dirname, 'public')))

// app.get('/Dashboard',function(req,res){
//     sessions=req.session;
//     if(session.user){
//         console.log(session.user);
//         res.sendFile(__dirname + '/pages/index.html');
//     }
//     else{
//         res.redirect("/")
//     }
  
//   });
    // res.sendFile(__dirname + '/pages/index.html');
// });


app.get('/Dashboard',function(req,res){
    res.sendFile(__dirname + '/pages/index.html');
});

app.get('/Book_an_Appointment',function(req,res){
    res.sendFile(__dirname + '/pages/forms-validation.html');
});

app.get('/Present_Appointments',function(req,res){
    res.sendFile(__dirname + '/pages/tables-general.html');
});

app.get('/Overall_Appointments',function(req,res){
    res.sendFile(__dirname + '/pages/tables-data.html');
});

app.get('/Prescription',function(req,res){
    res.sendFile(__dirname + '/pages/prescription.html');
});

app.get('/Profile',function(req,res){
    res.sendFile(__dirname + '/pages/users-profile.html');
});

app.get('/Payment',function(req,res){
    res.sendFile(__dirname + '/pages/payment1.html');
});

app.get('/Contact_Us',function(req,res){
    res.sendFile(__dirname + '/pages/pages-contact.html');
});



const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://chandu:chandu123@cluster0.wobdj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority", {
    useUnifiedTopology : true,
    useNewUrlParser : true,
}).then(console.log('Successfully Connected To MongoDB Database.'))


//Appointment  database connection

var appointment = require('./Models/Appoinment_Schema.js')

app.post('/checkdata', function(req,res){
    // console.log(req.body)
    var data = new appointment({
        name : req.body.Name,
        mailID : req.body.mailID,
        mobile : req.body.mobile,
        speciality : req.body.speciality,
        doctor : req.body.Doctor,
        date : req.body.Date,
        description : req.body.Description
    })

    data.save(function(err,result){
        if(err){
            console.log(err)
        }
        else{
            console.log(result)
            res.redirect('/Present_Appointments')
        }
    })
})


app.get('/activeAppointments', function(req,res){
    appointment.find({},function(err,docs){
        if(err){
            console.log(err)
        }
        else{
            console.log(docs)
            res.send(docs)
        }
    })
})


//paymentSchema

var payment = require('./Models/Payment_Schema.js')

app.post('/payment', function(req,res){
    // console.log(req.body)
    var data = new payment({
        cardowner : req.body.cardowner,
        cardnumber: req.body.cardnumber,
        expirymonth : req.body.expirymonth,
        expiryyear : req.body.expiryyear,
        cvv : req.body.cvv,
        // date : req.body.Date,
        // description : req.body.Description
    })

    data.save(function(err,result){
        if(err){
            console.log(err)
        }
        else{
            console.log(result)
            res.redirect('/Payment')
        }
    })
})


app.get('/payment', function(req,res){
    appointment.find({},function(err,docs){
        if(err){
            console.log(err)
        }
        else{
            console.log(docs)
            res.send(docs)
        }
    })
})


app.listen(2200,()=>{console.log('server started at 2200');});




var moment = require('moment');
var startTime = moment().utc().set({hour:11,minute:00});
var endTime = moment().utc().set({hour:23,minute:59});

 var timeStops = [];

while(startTime <= endTime){
    timeStops.push(new moment(startTime).format('HH:mm'));
    startTime.add(15, 'minutes');
}

console.log('timeStops ', timeStops)