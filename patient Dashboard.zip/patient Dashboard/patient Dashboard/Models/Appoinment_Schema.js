var mongoose = require('mongoose');
// var Schema = mongoose.Schema()

const AppointmentSchema = new mongoose.Schema({
	name:{type:String},
	mailID:{type:String},
	mobile:{type:String},
	speciality:{type:String},
	doctor:{type:String},
	date:{type:String},
	time:{type:String},
	description:{type:String}
})

module.exports = mongoose.model('Appointment', AppointmentSchema)